import DAO.AbstractDAO;
import Model.Client;
import Model.Product;
import Presentation.View.InitialGui;

import java.util.List;

public class Main {
    public static void main(String[] args) {

        InitialGui gui = new InitialGui();

        AbstractDAO<Client> clientTest = new AbstractDAO<>(Client.class);
        AbstractDAO<Product> productTest = new AbstractDAO<>(Product.class);

    }
}
