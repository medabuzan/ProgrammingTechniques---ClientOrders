package Model;

public class Order {

    private Integer clientid;
    private Integer productid;
    private Integer quantity;
    private Integer totalprice;

    public Order(Integer clientid, Integer productid, Integer quantity, Integer totalprice) {
        this.clientid = clientid;
        this.productid = productid;
        this.quantity = quantity;
        this.totalprice = totalprice;
    }

    public Order(){

    }

    public Integer getClientid() {
        return clientid;
    }

    public void setClientid(Integer clientid) {
        this.clientid = clientid;
    }

    public Integer getProductid() {
        return productid;
    }

    public void setProductid(Integer productid) {
        this.productid = productid;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Integer getTotalprice() {
        return totalprice;
    }

    public void setTotalprice(Integer totalprice) {
        this.totalprice = totalprice;
    }
}
