package Presentation.View;

import BusinessLogic.ClientController;
import Model.Client;

import java.lang.ref.Cleaner;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import java.awt.*;

public class ClientGui extends JFrame {
    private ImagePanel panel3;

    private JLabel lid,lname,laddress,lemail,lage;
    private JTextField id, name, address, email, age;
    private JButton add, edit, delete, viewAll;
    private JTable clientsTable;
    private ClientController clientController;

    public ClientGui(){

        super("CLIENT WINDOW");

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(730,440);
        this.panel3 = new ImagePanel(null, "gray.jpg");

        this.id = new JTextField("-");
        this.id.setForeground(Color.DARK_GRAY);
        this.id.setBounds(50,50,160,25);
        this.panel3.add(id);

        this.lid = new JLabel("CLIENT ID");
        this.lid.setForeground(Color.DARK_GRAY);
        this.lid.setBounds(55,25,160,25);
        this.panel3.add(lid);

        this.name = new JTextField("-");
        this.name.setForeground(Color.DARK_GRAY);
        this.name.setBounds(50,125,160,25);
        this.panel3.add(name);

        this.lname = new JLabel("CLIENT NAME");
        this.lname.setForeground(Color.DARK_GRAY);
        this.lname.setBounds(55,100,160,25);
        this.panel3.add(lname);

        this.age = new JTextField("-");
        this.age.setForeground(Color.DARK_GRAY);
        this.age.setBounds(280,125,160,25);
        this.panel3.add(age);

        this.lage = new JLabel("CLIENT AGE");
        this.lage.setForeground(Color.DARK_GRAY);
        this.lage.setBounds(280,100,160,25);
        this.panel3.add(lage);

        this.address = new JTextField("-");
        this.address.setForeground(Color.DARK_GRAY);
        this.address.setBounds(50,200,160,25);
        this.panel3.add(address);

        this.laddress = new JLabel("CLIENT ADDRESS");
        this.laddress.setForeground(Color.DARK_GRAY);
        this.laddress.setBounds(55,175,160,25);
        this.panel3.add(laddress);

        this.email = new JTextField("-");
        this.email.setForeground(Color.DARK_GRAY);
        this.email.setBounds(50,275,160,25);
        this.panel3.add(email);

        this.lemail = new JLabel("CLIENT EMAIL");
        this.lemail.setForeground(Color.DARK_GRAY);
        this.lemail.setBounds(55,250,160,25);
        this.panel3.add(lemail);



        this.add = new JButton("ADD CLIENT");
        this.add.addActionListener(e -> {
            this.addClient();
        });
        this.add.setForeground(Color.DARK_GRAY);
        this.add.setBounds(500,50,160,25);
        this.panel3.add(add);

        this.edit = new JButton("EDIT CLIENT");
        this.edit.addActionListener(e -> {
            this.editClient();
        });
        this.edit.setForeground(Color.DARK_GRAY);
        this.edit.setBounds(500,80,160,25);
        this.panel3.add(edit);

        this.delete = new JButton("DELETE CLIENT");
        this.delete.addActionListener(e -> {
            this.deleteClient();
        });
        this.delete.setForeground(Color.DARK_GRAY);
        this.delete.setBounds(500,110,160,25);
        this.panel3.add(delete);

        this.viewAll = new JButton("VIEW CLIENT LIST");
        this.viewAll.addActionListener(e -> {
            this.viewAll();
        });
        this.viewAll.setForeground(Color.DARK_GRAY);
        this.viewAll.setBounds(500,140,160,25);
        this.panel3.add(viewAll);


        this.clientController = new ClientController();


        this.getContentPane().add(panel3);

        this.setVisible(true);


    }



    public void getTextName(){

    }
    public void getTextId(){

    }

    public void getText
    public void addClient() {
    }

    public void editClient(){
    }

    public void deleteClient(){

        List<Client> clientList = clientController.fetch();

    }

    public void viewAll(){

        List<Client> clientList = clientController.fetch();
        String[] columns= {"id", "name", "age", "address", "email"};

        List<String[]> rows = new ArrayList<>();

        for(Client client : clientList)
        {
            System.out.println(client.getName());
            String[] row = {client.getId().toString(), client.getName(), client.getAge().toString(), client.getAddress(),client.getEmail()};
            rows.add(row);
        }

        Table table = new Table(columns, rows);



    }

}

