package Presentation.View;

import BusinessLogic.ClientController;
import BusinessLogic.ProductController;
import Model.Client;
import Model.Product;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ProductsGui extends JFrame{
    private ImagePanel panel2;
    private JButton add, edit, delete, viewAll;
    private JLabel lid, lname, linStock, lprice;
    private JTextField id, name, inStock, price;
    private ProductController productController;

    public ProductsGui( ) {

        super("PRODUCT OPERATIONS");



        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(730,440);

        this.panel2 = new ImagePanel(null, "gray.jpg");
        this.setVisible(true);

        this.id = new JTextField("-");
        this.id.setForeground(Color.DARK_GRAY);
        this.id.setBounds(50,50,160,25);
        this.panel2.add(id);

        this.lid = new JLabel("PRODUCT ID");
        this.lid.setForeground(Color.DARK_GRAY);
        this.lid.setBounds(55,25,160,25);
        this.panel2.add(lid);

        this.name = new JTextField("-");
        this.name.setForeground(Color.DARK_GRAY);
        this.name.setBounds(50,125,160,25);
        this.panel2.add(name);

        this.lname = new JLabel("PRODUCT NAME");
        this.lname.setForeground(Color.DARK_GRAY);
        this.lname.setBounds(55,100,160,25);
        this.panel2.add(lname);

        this.inStock = new JTextField("-");
        this.inStock.setForeground(Color.DARK_GRAY);
        this.inStock.setBounds(280,125,160,25);
        this.panel2.add(inStock);

        this.linStock = new JLabel("IN STOCK");
        this.linStock.setForeground(Color.DARK_GRAY);
        this.linStock.setBounds(280,100,160,25);
        this.panel2.add(linStock);

        this.price = new JTextField("-");
        this.price.setForeground(Color.DARK_GRAY);
        this.price.setBounds(50,200,160,25);
        this.panel2.add(price);

        this.lprice = new JLabel("PRICE");
        this.lprice.setForeground(Color.DARK_GRAY);
        this.lprice.setBounds(55,175,160,25);
        this.panel2.add(lprice);



        this.add = new JButton("ADD PRODUCT");
        this.add.addActionListener(e -> {
            ///this.displayInfo();
        });
        this.add.setForeground(Color.DARK_GRAY);
        this.add.setBounds(500,50,160,25);
        this.panel2.add(add);

        this.edit = new JButton("EDIT PRODUCT");
        this.edit.addActionListener(e -> {
            ///this.displayInfo();
        });
        this.edit.setForeground(Color.DARK_GRAY);
        this.edit.setBounds(500,80,160,25);
        this.panel2.add(edit);

        this.delete = new JButton("DELETE PRODUCT");
        this.delete.addActionListener(e -> {
            ///this.displayInfo();
        });
        this.delete.setForeground(Color.DARK_GRAY);
        this.delete.setBounds(500,110,160,25);
        this.panel2.add(delete);

        this.viewAll = new JButton("VIEW ALL PRODUCTS");
        this.viewAll.addActionListener(e -> {
            this.viewAll();
        });
        this.viewAll.setForeground(Color.DARK_GRAY);
        this.viewAll.setBounds(500,140,160,25);
        this.panel2.add(viewAll);

        this.productController = new ProductController();

        this.getContentPane().add(panel2);

        this.setVisible(true);
    }



    public void addClient() {


    }

    public void editClient(){
    }

    public void deleteClient(){

    }

    public void viewAll() {

        java.util.List<Product> productList = productController.fetchprod();
        String[] columns = {"id", "name", "stock", "price"};

        List<String[]> rows = new ArrayList<>();

        for (Product product : productList) {
            System.out.println(product.getName());
            String[] row = {product.getId().toString(), product.getName(), product.getStock().toString(), product.getPrice().toString()};
            rows.add(row);
        }

        Table table = new Table(columns, rows);

    }
    }
