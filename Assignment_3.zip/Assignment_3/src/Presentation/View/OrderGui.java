package Presentation.View;

import javax.swing.*;
import java.awt.*;

public class OrderGui extends JFrame{


    private ImagePanel panel1;
    JTextField product, client;
    JTextField quantity;
    JLabel lproduct, lclient, lquantity;
    JLabel totalprice;
    JButton select, createOrder;



    public OrderGui( ) {

        super("CREATE ORDER");


        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(730,440);

        this.panel1 = new ImagePanel(null, "gray.jpg");


        this.client = new JTextField("-");
        this.client.setForeground(Color.DARK_GRAY);
        this.client.setBounds(50,125,160,25);
        this.panel1.add(client);

        this.lclient = new JLabel("SELECT A CLIENT");
        this.lclient.setForeground(Color.DARK_GRAY);
        this.lclient.setBounds(55,100,160,25);
        this.panel1.add(lclient);

        this.product = new JTextField("-");
        this.product.setForeground(Color.DARK_GRAY);
        this.product.setBounds(280,125,160,25);
        this.panel1.add(product);

        this.lproduct = new JLabel("SELECT A PRODUCT");
        this.lproduct.setForeground(Color.DARK_GRAY);
        this.lproduct.setBounds(280,100,160,25);
        this.panel1.add(lproduct);

        this.quantity = new JTextField("-");
        this.quantity.setForeground(Color.DARK_GRAY);
        this.quantity.setBounds(50,200,160,25);
        this.panel1.add(quantity);

        this.lquantity = new JLabel("QUANTITY");
        this.lquantity.setForeground(Color.DARK_GRAY);
        this.lquantity.setBounds(55,175,160,25);
        this.panel1.add(lquantity);

        this.select = new JButton("SELECT OPTIONS");
        this.select.addActionListener(e -> {
            this.checkOptions();
        });
        this.select.setForeground(Color.DARK_GRAY);
        this.select.setBounds(500,140,160,25);
        this.panel1.add(select);

        this.createOrder = new JButton("SEND ORDER");
        this.createOrder.addActionListener(e -> {
            ///this.displayInfo();
        });
        this.createOrder.setForeground(Color.DARK_GRAY);
        this.createOrder.setBounds(500,175,160,25);
        this.panel1.add(createOrder);

        this.getContentPane().add(panel1);

        this.setVisible(true);
    }

    public void checkOptions(){
        ///checks if options are valid - existant client and product
//                                        -enough items in stock;
//                                        -displays totalprice

    }
}
