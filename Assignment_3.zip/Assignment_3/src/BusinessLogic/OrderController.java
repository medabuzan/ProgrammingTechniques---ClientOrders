package BusinessLogic;
import DAO.OrderDAO;
import Model.Order;
import java.util.List;

public class OrderController {

    private OrderDAO orderDAO = new OrderDAO();

    public OrderController(){

    }

    public List<Order> fetch (){
        return orderDAO.doFetchAll();

    }

}