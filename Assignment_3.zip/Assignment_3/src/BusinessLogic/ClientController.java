package BusinessLogic;

import DAO.ClientDAO;
import Model.Client;

import java.util.List;

public class ClientController {

    private ClientDAO clientDAO = new ClientDAO();

    public ClientController(){

    }

    public List<Client> fetch (){
        return clientDAO.doFetchAll();

    }

}
