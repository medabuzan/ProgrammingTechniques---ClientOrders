package BusinessLogic;

import DAO.ProductDAO;
import Model.Product;

import java.util.List;

public class ProductController {

    private ProductDAO productDAO = new ProductDAO();

    public ProductController(){

    }

    public List<Product> fetchprod (){
        return productDAO.doFetchAll();

    }

}
