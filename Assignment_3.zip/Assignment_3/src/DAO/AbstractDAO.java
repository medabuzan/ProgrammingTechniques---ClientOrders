package DAO;

import Connection.ConnectionFactory;
import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AbstractDAO<T> {

    protected static final Logger LOGGER = Logger.getLogger(AbstractDAO.class.getName());

    private final Class<T> type;

    @SuppressWarnings("unchecked")
    public AbstractDAO(Class<T> type) {
        this.type = type;
    }
    public List<T> createObjects(ResultSet result) {

        ArrayList<T> objectList = new ArrayList<>();

        try {
            while (result.next()) {
                T object = type.getDeclaredConstructor().newInstance();

                for(Field field : type.getDeclaredFields()) {
                    Object value = result.getObject(field.getName());
                    PropertyDescriptor propertyDescriptor = new PropertyDescriptor(field.getName(), type);
                    Method method = propertyDescriptor.getWriteMethod();
                    method.invoke(object, value);
                }
                objectList.add(object);
            }
        } catch (SQLException | NoSuchMethodException | InvocationTargetException | IllegalAccessException
                | InstantiationException | IntrospectionException e) {
            e.printStackTrace();
        }

        return objectList;
    }

    public void executeStatement(String statementString) {
        Connection connection = null;
        PreparedStatement statement = null;

        try {
            connection = ConnectionFactory.getConnection();
            statement = connection.prepareStatement(statementString);
            statement.execute();

        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, type.getName() + "DAO: updateEntity " + e.getMessage());
        } finally {
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
    }

    public List<T> doFetchAll() {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet result = null;
        String query = "SELECT * FROM " + type.getSimpleName()+ ";";

        try {
            connection = ConnectionFactory.getConnection();
            statement = connection.prepareStatement(query);
            result = statement.executeQuery();
            return createObjects(result);

        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, type.getName() + "DAO: updateEntity " + e.getMessage());
        } finally {
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
            return null;
    }

    public List<T> doDelete(){
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet result = null;
        String query = "DELETE FROM "+ type.getSimpleName()+"WHERE NAME LIKE"+type.getName()+ ";";

        try {
            connection = ConnectionFactory.getConnection();
            statement = connection.prepareStatement(query);
            result = statement.executeQuery();
            return createObjects(result);

        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, type.getName() + "DAO: updateEntity " + e.getMessage());
        } finally {
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
        return null;
    }
}
