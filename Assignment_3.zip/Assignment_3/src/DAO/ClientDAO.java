package DAO;

import Model.Client;

public class ClientDAO extends AbstractDAO<Client>{
    public ClientDAO() {
        super(Client.class);
    }
}
